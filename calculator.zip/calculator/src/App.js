import React, { useState } from 'react';

const App = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  function add(numbers){
  if (!numbers) return 0;

  let delimiter = /,|\n/;
  if (numbers.startsWith("//")) {
    const delimiterEndIndex = numbers.indexOf("\n");
    delimiter = new RegExp(
      numbers.slice(2, delimiterEndIndex).replace(/\[|\]/g, "")
    );
    numbers = numbers.slice(delimiterEndIndex + 1);
  }
  console.log(numbers)

  const numArray = numbers.split(delimiter).map((n) => parseInt(n, 10));

  const negativeNumbers = numArray.filter((n) => n < 0);

  if (negativeNumbers.length > 0) {
    throw new Error(`Negative numbers is not allowed: ${negativeNumbers.join(", ")}`);
  }

  return numArray.reduce((sum, n) => sum + n, 0);
}


  const handleCalculate = () => {
    try {
      const sum = add(input);
      setResult(`Result: ${sum}`);
    } catch (error) {
      setResult(`Error: ${error.message}`);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Calculator</h1>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Enter numbers"
      />
      <button
        onClick={handleCalculate}
      >
        Calculate
      </button>
      <div style={{ marginTop: '20px', fontSize: '28px' }}>{result}</div>
    </div>
  );
};

export default App;
